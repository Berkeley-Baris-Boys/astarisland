#!/usr/bin/env python3
"""Local Norse civilization simulator for Astar Island Monte Carlo prediction."""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

OCEAN = 10
PLAINS = 11
EMPTY = 0
SETTLEMENT = 1
PORT = 2
RUIN = 3
FOREST = 4
MOUNTAIN = 5

BUILDABLE_TERRAIN = {PLAINS, EMPTY, RUIN}
STATIC_TERRAIN = {OCEAN, MOUNTAIN}

CODE_TO_CLASS = {0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 10: 0, 11: 0}

# Calibration-oriented dynamics constants (Round 2 baseline).
FOOD_INCOME_PER_TILE = 0.10
BASE_FOOD_DRAIN = 0.16
POP_FOOD_DRAIN = 0.06
POP_GROWTH_FACTOR = 0.07
POP_SHRINK_FACTOR = 0.12

PLAINS_COLONIZE_BASE = 0.085
PLAINS_COLONIZE_SCALE = 0.16
FOREST_CLEAR_RATE = 0.033

PLAINS_TO_FOREST_NEIGHBOR_RATE = 0.018
PLAINS_TO_FOREST_SLOW_RATE = 0.005

DEATH_TO_FOREST_PROB = 0.35
DEATH_TO_PLAINS_OR_EMPTY_PROB = 0.55


def _sorted_offsets(radius: int) -> List[Tuple[int, int]]:
    offsets: List[Tuple[int, int]] = []
    for dy in range(-radius, radius + 1):
        for dx in range(-radius, radius + 1):
            if dx == 0 and dy == 0:
                continue
            dist = np.hypot(dx, dy)
            if dist <= radius:
                offsets.append((dx, dy))
    offsets.sort(key=lambda p: (np.hypot(p[0], p[1]), p[1], p[0]))
    return offsets


OFFSETS_R3 = _sorted_offsets(3)
OFFSETS_R2 = _sorted_offsets(2)


class World:
    def __init__(
        self,
        grid: np.ndarray,
        settlements: List[dict],
        params: dict,
        sim_seed: int,
    ):
        self.rng = np.random.default_rng(int(sim_seed))
        self.sim_seed = int(sim_seed)

        terrain = np.asarray(grid, dtype=np.int64)
        if terrain.ndim != 2:
            raise ValueError("grid must be 2D")

        # Terrain layer stores non-settlement state; settlements are overlaid in _build_grid.
        self.terrain = terrain.copy()
        self.terrain[np.isin(self.terrain, [SETTLEMENT, PORT])] = PLAINS
        self.height, self.width = self.terrain.shape

        self.params = {
            "faction_aggression": float(np.clip(params.get("faction_aggression", 0.0), 0.0, 1.0)),
            "forest_growth_rate": float(np.clip(params.get("forest_growth_rate", 0.0), 0.0, 1.0)),
            "winter_severity": float(np.clip(params.get("winter_severity", 0.0), 0.0, 1.0)),
            "trade_activity": float(np.clip(params.get("trade_activity", 0.0), 0.0, 1.0)),
        }

        self.settlements: List[Dict[str, Any]] = []
        self._coord_to_index: Dict[Tuple[int, int], int] = {}
        self.ruin_port = np.zeros((self.height, self.width), dtype=bool)

        for raw in settlements:
            s = self._normalize_settlement(raw)
            if s is None:
                continue
            x = int(s["x"])
            y = int(s["y"])
            key = (x, y)
            if key in self._coord_to_index:
                self.settlements[self._coord_to_index[key]] = s
            else:
                self._coord_to_index[key] = len(self.settlements)
                self.settlements.append(s)

            if not s["alive"]:
                if self.terrain[y, x] not in STATIC_TERRAIN:
                    self.terrain[y, x] = RUIN
                self.ruin_port[y, x] = bool(s["has_port"])

    @classmethod
    def from_api(
        cls,
        initial_state: dict,
        params: dict,
        sim_seed: int,
    ) -> "World":
        grid = np.asarray(initial_state["grid"], dtype=np.int64)
        api_settlements = initial_state.get("settlements", [])
        rng = np.random.default_rng(int(sim_seed))
        n_factions = max(2, min(6, max(1, len(api_settlements))))

        settlements: List[Dict[str, Any]] = []
        for s in api_settlements:
            x = int(s.get("x", 0))
            y = int(s.get("y", 0))
            has_port = bool(s.get("has_port", False))
            alive = bool(s.get("alive", True))
            settlements.append(
                {
                    "x": x,
                    "y": y,
                    "population": float(rng.uniform(1.0, 3.0)),
                    "food": float(rng.uniform(0.5, 1.5)),
                    "wealth": float(rng.uniform(0.3, 1.0)),
                    "defense": float(rng.uniform(0.3, 0.8)),
                    "tech": float(rng.uniform(0.1, 0.5)),
                    "has_port": has_port,
                    "alive": alive,
                    "owner_id": int(rng.integers(0, n_factions)),
                    "longships": int(has_port),
                }
            )

        return cls(grid=grid, settlements=settlements, params=params, sim_seed=sim_seed)

    def run_simulation(self) -> np.ndarray:
        for _ in range(50):
            self._phase_growth()
            self._phase_conflict()
            self._phase_trade()
            self._phase_winter()
            self._phase_environment()
        return self._build_grid()

    def _normalize_settlement(self, raw: dict) -> Optional[Dict[str, Any]]:
        try:
            x = int(raw["x"])
            y = int(raw["y"])
        except (KeyError, TypeError, ValueError):
            return None
        if not (0 <= x < self.width and 0 <= y < self.height):
            return None
        return {
            "x": x,
            "y": y,
            "population": float(raw.get("population", 1.0)),
            "food": float(raw.get("food", 0.5)),
            "wealth": float(raw.get("wealth", 0.3)),
            "defense": float(raw.get("defense", 0.3)),
            "tech": float(raw.get("tech", 0.2)),
            "has_port": bool(raw.get("has_port", False)),
            "alive": bool(raw.get("alive", True)),
            "owner_id": int(raw.get("owner_id", 0)),
            "longships": int(raw.get("longships", int(bool(raw.get("has_port", False))))),
        }

    def _neighbor_count(self, mask: np.ndarray, connectivity: int) -> np.ndarray:
        p = np.pad(mask.astype(np.int16, copy=False), 1, mode="constant")
        if connectivity == 4:
            return p[:-2, 1:-1] + p[2:, 1:-1] + p[1:-1, :-2] + p[1:-1, 2:]
        if connectivity == 8:
            return (
                p[:-2, :-2]
                + p[:-2, 1:-1]
                + p[:-2, 2:]
                + p[1:-1, :-2]
                + p[1:-1, 2:]
                + p[2:, :-2]
                + p[2:, 1:-1]
                + p[2:, 2:]
            )
        raise ValueError("connectivity must be 4 or 8")

    def _alive_indices(self) -> List[int]:
        return [i for i, s in enumerate(self.settlements) if s["alive"]]

    def _occupied_alive_mask(self) -> np.ndarray:
        occ = np.zeros((self.height, self.width), dtype=bool)
        for s in self.settlements:
            if s["alive"]:
                occ[int(s["y"]), int(s["x"])] = True
        return occ

    def _is_adjacent_ocean(self, x: int, y: int) -> bool:
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx = x + dx
            ny = y + dy
            if 0 <= nx < self.width and 0 <= ny < self.height and self.terrain[ny, nx] == OCEAN:
                return True
        return False

    def _find_nearest_buildable(
        self,
        x: int,
        y: int,
        radius: int,
        occupied_alive: np.ndarray,
    ) -> Optional[Tuple[int, int]]:
        offsets = OFFSETS_R3 if radius == 3 else _sorted_offsets(radius)
        for dx, dy in offsets:
            nx, ny = x + dx, y + dy
            if not (0 <= nx < self.width and 0 <= ny < self.height):
                continue
            if occupied_alive[ny, nx]:
                continue
            cell = int(self.terrain[ny, nx])
            if cell in BUILDABLE_TERRAIN:
                return nx, ny
        return None

    def _find_nearest_terrain_cell(
        self,
        x: int,
        y: int,
        radius: int,
        occupied_alive: np.ndarray,
        allowed_codes: Sequence[int],
    ) -> Optional[Tuple[int, int]]:
        if radius == 2:
            offsets = OFFSETS_R2
        elif radius == 3:
            offsets = OFFSETS_R3
        else:
            offsets = _sorted_offsets(radius)
        allowed = set(int(v) for v in allowed_codes)
        for dx, dy in offsets:
            nx, ny = x + dx, y + dy
            if not (0 <= nx < self.width and 0 <= ny < self.height):
                continue
            if occupied_alive[ny, nx]:
                continue
            if int(self.terrain[ny, nx]) in allowed:
                return nx, ny
        return None

    def _spawn_or_reactivate(
        self,
        x: int,
        y: int,
        population: float,
        food: float,
        wealth: float,
        defense: float,
        tech: float,
        owner_id: int,
        has_port: bool,
        longships: int,
    ) -> None:
        key = (x, y)
        if key in self._coord_to_index:
            idx = self._coord_to_index[key]
            s = self.settlements[idx]
            s.update(
                {
                    "population": float(population),
                    "food": float(food),
                    "wealth": float(wealth),
                    "defense": float(defense),
                    "tech": float(tech),
                    "owner_id": int(owner_id),
                    "has_port": bool(has_port),
                    "longships": int(longships),
                    "alive": True,
                }
            )
            self.settlements[idx] = s
        else:
            s = {
                "x": int(x),
                "y": int(y),
                "population": float(population),
                "food": float(food),
                "wealth": float(wealth),
                "defense": float(defense),
                "tech": float(tech),
                "owner_id": int(owner_id),
                "has_port": bool(has_port),
                "longships": int(longships),
                "alive": True,
            }
            self._coord_to_index[key] = len(self.settlements)
            self.settlements.append(s)
        self.ruin_port[y, x] = False

    def _collapse_settlement(self, idx: int) -> None:
        s = self.settlements[idx]
        if not s["alive"]:
            return
        s["alive"] = False
        x = int(s["x"])
        y = int(s["y"])
        if self.terrain[y, x] in STATIC_TERRAIN:
            return

        roll = float(self.rng.random())
        if roll < DEATH_TO_FOREST_PROB:
            self.terrain[y, x] = FOREST
            self.ruin_port[y, x] = False
        elif roll < (DEATH_TO_FOREST_PROB + DEATH_TO_PLAINS_OR_EMPTY_PROB):
            self.terrain[y, x] = PLAINS if self.rng.random() < 0.55 else EMPTY
            self.ruin_port[y, x] = False
        else:
            self.terrain[y, x] = RUIN
            self.ruin_port[y, x] = bool(s["has_port"])

    def _phase_growth(self) -> None:
        alive_indices = self._alive_indices()
        if not alive_indices:
            return

        current_grid = self._build_grid()
        food_source = (current_grid == FOREST) | (current_grid == PLAINS)
        nearby_food = self._neighbor_count(food_source, connectivity=8)
        occupied_alive = self._occupied_alive_mask()
        trade_activity = self.params["trade_activity"]

        for idx in alive_indices:
            s = self.settlements[idx]
            if not s["alive"]:
                continue
            x = int(s["x"])
            y = int(s["y"])

            food_income = float(nearby_food[y, x]) * FOOD_INCOME_PER_TILE
            if s["has_port"]:
                food_income += 0.04 + 0.08 * trade_activity
                s["wealth"] += 0.03 + 0.08 * trade_activity
            s["food"] += food_income

            upkeep = BASE_FOOD_DRAIN + POP_FOOD_DRAIN * float(s["population"])
            if s["has_port"]:
                upkeep *= 0.88
            s["food"] -= upkeep

            if s["food"] > 0.3:
                s["population"] += POP_GROWTH_FACTOR * s["food"]
            else:
                s["population"] += POP_SHRINK_FACTOR * s["food"]
            if s["food"] < -0.2:
                s["population"] -= 0.05
            s["population"] = min(float(s["population"]), 8.0)
            s["population"] = max(float(s["population"]), 0.0)

            drive = float(np.clip((s["population"] - 1.0) / 3.0, 0.0, 1.0))
            food_drive = float(np.clip((s["food"] + 0.6) / 2.0, 0.0, 1.0))
            colonize_strength = drive * food_drive

            if s["population"] > 1.0 and self.rng.random() < (PLAINS_COLONIZE_BASE + PLAINS_COLONIZE_SCALE * colonize_strength):
                forest_target = self._find_nearest_terrain_cell(
                    x=x,
                    y=y,
                    radius=3,
                    occupied_alive=occupied_alive,
                    allowed_codes=(FOREST,),
                )
                land_target = self._find_nearest_terrain_cell(
                    x=x,
                    y=y,
                    radius=3,
                    occupied_alive=occupied_alive,
                    allowed_codes=(PLAINS, EMPTY, RUIN),
                )
                forest_bias = 0.20 + 0.20 * colonize_strength
                if forest_target is not None and (land_target is None or self.rng.random() < forest_bias):
                    target = forest_target
                else:
                    target = land_target
                if target is not None:
                    nx, ny = target
                    colonizing_forest = bool(self.terrain[ny, nx] == FOREST)
                    if colonizing_forest:
                        # Expanding onto Forest clears that forest tile.
                        self.terrain[ny, nx] = PLAINS
                    child_has_port = self._is_adjacent_ocean(nx, ny) and (
                        self.rng.random() < (0.25 + 0.25 * trade_activity)
                    )
                    self._spawn_or_reactivate(
                        x=nx,
                        y=ny,
                        population=0.95 if colonizing_forest else 1.0,
                        food=0.42 if colonizing_forest else 0.50,
                        wealth=0.24 if colonizing_forest else 0.30,
                        defense=0.26 if colonizing_forest else 0.30,
                        tech=max(0.1, float(s["tech"]) * (0.75 if colonizing_forest else 0.80)),
                        owner_id=int(s["owner_id"]),
                        has_port=child_has_port,
                        longships=int(child_has_port),
                    )
                    occupied_alive[ny, nx] = True

            # Active settlements clear nearby forests (forest -> plains/empty).
            clear_prob = FOREST_CLEAR_RATE * (0.95 + 0.15 * float(np.clip(s["population"] / 5.0, 0.0, 1.0)))
            for dy, dx in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                ny = y + dy
                nx = x + dx
                if not (0 <= nx < self.width and 0 <= ny < self.height):
                    continue
                if self.terrain[ny, nx] == FOREST and self.rng.random() < clear_prob:
                    self.terrain[ny, nx] = PLAINS if self.rng.random() < 0.6 else EMPTY

            if (not s["has_port"]) and self._is_adjacent_ocean(x, y) and s["wealth"] > 0.70 and self.rng.random() < 0.20:
                s["has_port"] = True
                s["longships"] = int(s.get("longships", 0)) + 1

    def _phase_conflict(self) -> None:
        alive_indices = self._alive_indices()
        if len(alive_indices) < 2:
            return

        aggression = self.params["faction_aggression"]
        shuffled = np.array(alive_indices, dtype=np.int64)
        self.rng.shuffle(shuffled)

        for idx in shuffled.tolist():
            attacker = self.settlements[idx]
            if not attacker["alive"]:
                continue

            raid_prob = 0.05 * aggression
            if attacker["food"] < 0.3:
                raid_prob *= 3.0
            if attacker["tech"] > 0.5:
                raid_prob *= 1.5
            if self.rng.random() >= raid_prob:
                continue

            ax = float(attacker["x"])
            ay = float(attacker["y"])
            max_range = 5.0 + float(int(attacker.get("longships", 0)) * 8)
            max_range_sq = max_range * max_range
            owner = int(attacker["owner_id"])

            best_idx: Optional[int] = None
            best_d2 = float("inf")
            for j, target in enumerate(self.settlements):
                if j == idx or (not target["alive"]) or int(target["owner_id"]) == owner:
                    continue
                dx = float(target["x"]) - ax
                dy = float(target["y"]) - ay
                d2 = dx * dx + dy * dy
                if d2 <= max_range_sq and d2 < best_d2:
                    best_d2 = d2
                    best_idx = j

            if best_idx is None:
                continue

            target = self.settlements[best_idx]
            attack_power = attacker["population"] * 0.3 + attacker["tech"] * 0.5 + float(self.rng.uniform(0.0, 0.3))
            defend_power = target["defense"] + target["population"] * 0.2 + float(self.rng.uniform(0.0, 0.2))

            if attack_power > defend_power:
                attacker["food"] += target["food"] * 0.4
                attacker["wealth"] += target["wealth"] * 0.3
                target["food"] *= 0.6
                target["wealth"] *= 0.7
                target["defense"] *= 0.8
                target["population"] -= 0.5
                if self.rng.random() < 0.15 * aggression:
                    target["owner_id"] = attacker["owner_id"]
                if target["population"] <= 0.3:
                    self._collapse_settlement(best_idx)
            else:
                attacker["population"] -= 0.3
                attacker["food"] *= 0.8

    def _phase_trade(self) -> None:
        trade_activity = self.params["trade_activity"]
        ports = [i for i, s in enumerate(self.settlements) if s["alive"] and s["has_port"]]
        if ports:
            for i in ports:
                s = self.settlements[i]
                s["food"] += 0.02 + 0.05 * trade_activity
                s["wealth"] += 0.03 + 0.08 * trade_activity
        if len(ports) < 2:
            return

        for a in range(len(ports)):
            i = ports[a]
            s1 = self.settlements[i]
            x1 = float(s1["x"])
            y1 = float(s1["y"])
            for b in range(a + 1, len(ports)):
                j = ports[b]
                s2 = self.settlements[j]
                dx = float(s2["x"]) - x1
                dy = float(s2["y"]) - y1
                dist = float(np.hypot(dx, dy))
                trade_range = 10.0 + max(float(s1["tech"]), float(s2["tech"])) * 5.0
                if dist >= trade_range:
                    continue

                trade_amount = min(float(s1["food"]), float(s2["food"])) * (0.08 + 0.08 * trade_activity)
                if trade_amount <= 0.0:
                    continue

                s1["wealth"] += trade_amount * 0.5
                s2["wealth"] += trade_amount * 0.5
                s1["food"] += trade_amount * 0.1
                s2["food"] += trade_amount * 0.1

                tech_diff = abs(float(s1["tech"]) - float(s2["tech"]))
                diffusion = tech_diff * 0.05
                s1["tech"] += diffusion
                s2["tech"] += diffusion

    def _phase_winter(self) -> None:
        winter_loss = 0.22 + 0.32 * self.params["winter_severity"] + float(self.rng.uniform(-0.04, 0.12))
        for idx, s in enumerate(self.settlements):
            if not s["alive"]:
                continue
            loss = winter_loss * float(s["population"]) * 0.32
            if s["has_port"]:
                loss *= 0.86
            s["food"] -= loss
            if s["food"] < 0.0:
                s["population"] += 0.08 * s["food"]
            if s["food"] < -0.4:
                s["population"] -= 0.10
            collapse_roll = 0.02 + (0.05 if s["food"] < -0.1 else 0.0)
            if s["has_port"]:
                collapse_roll *= 0.70
            if s["food"] < -0.7 or s["population"] < 0.30 or self.rng.random() < collapse_roll:
                self._collapse_settlement(idx)

    def _nearest_alive_settlement_within(self, x: int, y: int, radius: float) -> Optional[int]:
        best_idx: Optional[int] = None
        best_d2 = float("inf")
        r2 = radius * radius
        for idx, s in enumerate(self.settlements):
            if not s["alive"]:
                continue
            dx = float(s["x"]) - float(x)
            dy = float(s["y"]) - float(y)
            d2 = dx * dx + dy * dy
            if d2 <= r2 and d2 < best_d2:
                best_d2 = d2
                best_idx = idx
        return best_idx

    def _phase_environment(self) -> None:
        growth_rate = self.params["forest_growth_rate"]
        occupied = self._occupied_alive_mask()

        # Forest spread to 4-connected Plains/Empty cells.
        if growth_rate > 0.0:
            forest_mask = self.terrain == FOREST
            forest_neighbors = self._neighbor_count(forest_mask, connectivity=4)
            spread_targets = np.isin(self.terrain, [PLAINS, EMPTY]) & (~occupied) & (forest_neighbors > 0)
            if np.any(spread_targets):
                p = 1.0 - np.power(
                    1.0 - PLAINS_TO_FOREST_NEIGHBOR_RATE * growth_rate,
                    forest_neighbors.astype(np.float64),
                )
                rnd = self.rng.random((self.height, self.width))
                to_forest = spread_targets & (rnd < p)
                self.terrain[to_forest] = FOREST

        # Ruin handling: reclamation, then nature takeover.
        ruin_cells = np.argwhere((self.terrain == RUIN) & (~occupied))
        for y, x in ruin_cells.tolist():
            sponsor_idx = self._nearest_alive_settlement_within(int(x), int(y), radius=4.0)
            if sponsor_idx is not None and self.rng.random() < 0.12:
                sponsor = self.settlements[sponsor_idx]
                restored_port = bool(self.ruin_port[y, x]) or self._is_adjacent_ocean(int(x), int(y))
                self._spawn_or_reactivate(
                    x=int(x),
                    y=int(y),
                    population=0.8,
                    food=0.4,
                    wealth=0.2,
                    defense=0.2,
                    tech=max(0.1, float(sponsor["tech"]) * 0.7),
                    owner_id=int(sponsor["owner_id"]),
                    has_port=restored_port,
                    longships=int(restored_port),
                )
                continue

            if self.rng.random() < 0.05 * growth_rate:
                self.terrain[y, x] = FOREST
                self.ruin_port[y, x] = False
            elif self.rng.random() < 0.02:
                self.terrain[y, x] = PLAINS if self.rng.random() < 0.5 else EMPTY
                self.ruin_port[y, x] = False

        # Slow natural growth from adjacent forest to Plains/Empty.
        occupied = self._occupied_alive_mask()
        forest_mask = self.terrain == FOREST
        forest_neighbors = self._neighbor_count(forest_mask, connectivity=4)
        slow_targets = np.isin(self.terrain, [PLAINS, EMPTY]) & (~occupied) & (forest_neighbors > 0)
        if np.any(slow_targets) and growth_rate > 0.0:
            rnd = self.rng.random((self.height, self.width))
            self.terrain[slow_targets & (rnd < (PLAINS_TO_FOREST_SLOW_RATE * growth_rate))] = FOREST

    def _build_grid(self) -> np.ndarray:
        out = self.terrain.copy()
        for s in self.settlements:
            x = int(s["x"])
            y = int(s["y"])
            if not (0 <= x < self.width and 0 <= y < self.height):
                continue
            if s["alive"]:
                out[y, x] = PORT if s["has_port"] else SETTLEMENT
        return out


class MonteCarloSimulator:
    def __init__(self, initial_state: dict, params: dict, n_runs: int = 200):
        self.initial_state = initial_state
        self.params = params
        self.n_runs = int(n_runs)

    def run(self) -> np.ndarray:
        height = len(self.initial_state["grid"])
        width = len(self.initial_state["grid"][0])
        counts = np.zeros((height, width, 6), dtype=np.int32)

        max_code = max(CODE_TO_CLASS.keys())
        lookup = np.zeros(max_code + 1, dtype=np.int8)
        for code, cls_idx in CODE_TO_CLASS.items():
            lookup[code] = int(cls_idx)

        for i in range(self.n_runs):
            world = World.from_api(self.initial_state, self.params, sim_seed=i * 137 + 42)
            final_grid = world.run_simulation()

            if final_grid.min() >= 0 and final_grid.max() <= max_code:
                class_grid = lookup[final_grid]
            else:
                class_grid = np.zeros_like(final_grid, dtype=np.int8)
                valid = (final_grid >= 0) & (final_grid <= max_code)
                class_grid[valid] = lookup[final_grid[valid]]

            for cls_idx in range(6):
                counts[:, :, cls_idx] += (class_grid == cls_idx).astype(np.int32)

        probs = counts.astype(np.float64) / float(self.n_runs)
        probs = np.maximum(probs, 0.01)
        probs = probs / probs.sum(axis=2, keepdims=True)
        return probs


def calibrate(simulator_class, n_runs: int = 300) -> float:
    """
    Run simulator on a standard map and compare against Round 2 targets.
    Returns mean absolute error (lower is better).
    """
    target = {
        1: np.array([0.378, 0.404, 0.010, 0.034, 0.165, 0.010]),
        4: np.array([0.108, 0.195, 0.013, 0.018, 0.656, 0.010]),
        11: np.array([0.720, 0.188, 0.015, 0.019, 0.048, 0.010]),
    }

    grid = [[11] * 20 for _ in range(20)]
    for y in range(6, 14):
        for x in range(6, 14):
            grid[y][x] = 4
    for x in range(20):
        grid[0][x] = 10
        grid[19][x] = 10
    grid[10][10] = 5

    settlements = [
        {"x": 3, "y": 3, "has_port": False, "alive": True},
        {"x": 16, "y": 3, "has_port": False, "alive": True},
        {"x": 3, "y": 16, "has_port": True, "alive": True},
        {"x": 16, "y": 16, "has_port": False, "alive": True},
    ]

    initial_state = {"grid": grid, "settlements": settlements}
    params = {
        "faction_aggression": 0.02,
        "forest_growth_rate": 0.30,
        "winter_severity": 0.05,
        "trade_activity": 0.20,
    }

    sim = simulator_class(initial_state, params, n_runs=n_runs)
    probs = sim.run()

    ig = np.array(grid, dtype=np.int64)
    for s in settlements:
        ig[int(s["y"]), int(s["x"])] = PORT if bool(s.get("has_port", False)) else SETTLEMENT

    total_error = 0.0
    n_codes = 0
    for code, tgt in target.items():
        mask = ig == int(code)
        if not np.any(mask):
            continue
        avg = probs[mask].mean(axis=0)
        error = float(np.abs(avg - tgt).mean())
        print(f"  Code {code}: error={error:.4f}  got={np.round(avg, 3)}  target={np.round(tgt, 3)}")
        total_error += error
        n_codes += 1

    mean_error = total_error / max(1, n_codes)
    print(f"  Mean absolute error: {mean_error:.4f}")
    print("  (target: < 0.05 for good calibration)")
    return mean_error


if __name__ == "__main__":
    print("Running calibration (Round 2 baseline)...")
    mae = calibrate(MonteCarloSimulator, n_runs=300)
    if mae < 0.05:
        print("Calibration target met.")
    else:
        print("Calibration needs more tuning.")
